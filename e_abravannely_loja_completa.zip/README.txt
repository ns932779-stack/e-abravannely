E ABRAVANNELY — VERSÃO COMPLETA
Abra index.html.
Recursos: catálogo, busca, filtros, carrinho persistente, checkout de pedido, estoque, painel administrativo e armazenamento local.
IMPORTANTE: o checkout cria pedidos localmente neste navegador; para pagamentos reais e pedidos compartilhados entre clientes é necessário conectar backend, banco de dados, gateway de pagamento e hospedagem.
